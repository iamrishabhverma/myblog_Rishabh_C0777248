//function list


//thank yoy alert
function qual(){
	alert("This is my qualifications page!");	
}